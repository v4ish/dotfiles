#include<stdio.h>
int stack[100],choice,n,top,x,i;
void push(void);
void pop(void);
void display(void);
void main()	
{
	top = -1;
	printf("Enter the size of stack: ");
	scanf("%d", &n);
	printf("\n \t Stack Operations Using Array");
	printf("\n\t 1: PUSH \n\t 2: POP \n\t 3: DISPLAY \n\t 4: EXIT \n");
	do{
		printf("\n Enter the choice: ");
		scanf("%d", &choice);
		switch(choice)
		{
			case 1:
			{
				push();
				break;
			}
			case 2:
			{
				pop();
				break;
			}
			case 3:
			{
				display();
				break;
			}
			case 4:
			{
				break;
			}
			default:
			{
				printf("\n\t ***ENTER A VALID CHOICE***");
			}
		}
	}
	while(choice!=4);
}
void push()
{
	if(top>=n-1){
		printf("\n STACK IS FULL");
	}else{
		printf("\n Enter a value to be pushed: ");
		scanf("%d",&x);
		top++;
		stack[top] = x;
	}
}
void pop()
{
	if(top==-1){
		printf("\n STACK IS EMPTY");
	}else{
		printf("THE POPPED ELEMENT IS %d \n", stack[top]);
		top--;
	}
}
void display()
{
	if(top>=0){
		printf("THE ELEMENT IN STACK IS \n");
		for(i=top;i>=0;i--)
			printf("%d \n", stack[i]);
	}else{
		printf("\n\t STACK IS EMPTY \n");
	}
}
