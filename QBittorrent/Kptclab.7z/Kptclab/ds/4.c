#include <stdio.h>
#include <stdlib.h>

void randominsert();
void create(int);
void deleteNode();
void display();

struct node {
    int data;
    struct node *next;
};

struct node *head = NULL;

int main() {
    int choice;
    printf("\n\n***** Main Menu *****\n");
    printf("\n Choose one option from the following list\n");
    printf("================================\n");
    printf("\n1: Insert\n2: Display\n3: Delete\n4: Exit\n");

    do {
        printf("\n Enter your choice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                randominsert();
                break;
            case 2:
                display();
                break;
            case 3:
                deleteNode();
                break;
            case 4:
                exit(0);
            default:
                printf("\n Invalid choice\n");
        }
    } while (choice != 4);

    return 0;
}

void display() {
    struct node *ptr = head;
    if (ptr == NULL) {
        printf("Nothing to print\n");
    } else {
        printf("\n Printing values...\n");
        while (ptr != NULL) {
            printf("%d\n", ptr->data);
            ptr = ptr->next;
        }
    }
}

void create(int item) {
    struct node *ptr = (struct node*)malloc(sizeof(struct node));
    if (ptr == NULL) {
        printf("\nOverflow\n");
    } else {
        ptr->data = item;
        ptr->next = head;
        head = ptr;
        printf("\nNode inserted\n");
    }
}

void randominsert() {
    struct node *ptr = (struct node*)malloc(sizeof(struct node));
    struct node *temp;
    int i, loc, item;
    printf("Enter the item you want to insert: ");
    scanf("%d", &item);
    if (ptr == NULL) {
        printf("\nOverflow\n");
    } else {
        printf("Enter the location: ");
        scanf("%d", &loc);
        if (loc <= 1) {
            create(item);
        } else {
            temp = head;
            for (i = 1; i < loc - 1 && temp != NULL; i++) {
                temp = temp->next;
            }
            if (temp == NULL) {
                printf("\nCan't insert\n");
            } else {
                ptr->data = item;
                ptr->next = temp->next;
                temp->next = ptr;
                printf("\nNode inserted\n");
            }
        }
    }
}

void deleteNode() {
    if (head == NULL) {
        printf("\nList is empty\n");
        return;
    }
    int loc, i;
    struct node *ptr = head;
    struct node *prev = NULL;
    printf("\nEnter the location of the node you want to delete: ");
    scanf("%d", &loc);
    if (loc == 1) {
        head = ptr->next;
        free(ptr);
        printf("\nDeleted node at location %d\n", loc);
        return;
    }
    for (i = 1; i < loc && ptr != NULL; i++) {
        prev = ptr;
        ptr = ptr->next;
    }
    if (ptr == NULL) {
        printf("\nCan't delete\n");
    } else {
        prev->next = ptr->next;
        free(ptr);
        printf("\nDeleted node at location %d\n", loc);
    }
}
