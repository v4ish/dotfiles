#include<stdio.h>
#include<stdlib.h>
struct node{
	int data;
	struct node *right_child;
	struct node *left_child;
};
struct node *new_node(int x){
	struct node *temp;
	temp=(struct node*)malloc(sizeof(struct node));
	temp->data=x;
	temp->left_child=NULL;
	temp->right_child=NULL;
	return temp;
}
struct node* insert(struct node *root,int x){
	if(root==NULL)
		return new_node(x);
	else if(x>root->data)
		root->right_child=insert(root->right_child, x);
	else
		root->left_child=insert(root->left_child, x);
	return root;
}
void postorder(struct node *root){
	if(root != NULL){
		postorder(root->left_child);
		postorder(root->right_child);
		printf("%d \t", root->data);
	}
}
int main(){
	int i,m,n,r;
	printf("Enter Root node : ");
	scanf("%d",&n);
	printf("How many nodes you want : ");
	scanf("%d",&m);
	struct node *root;
	root = new_node(n);
	printf("Enter the node values : ");
	for(i=1;i<=m;i++){
		scanf("%d",&r);
		insert(root,r);
	}
	printf("\nTree nodes in postorder Traversal are :  \n");
	postorder(root);
}
