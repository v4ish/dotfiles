#include<stdio.h>
#include<stdlib.h>
#define SIZE 100
void enqueue();
void dequeue();
void show();
int inp_arr[SIZE];
int rear=-1;
int front=-1;
void main()
{
	int ch;
	while(1){
		printf("\n1 : ENQUEUE OPERATION \n");
		printf("2 : DEQUEUE OPERATION \n");
		printf("3 : DISPLAY THE QUEUE \n");
		printf("4 : EXIT \n");
		printf("ENTER YOUR CHOICE OF OPERATIONS: ");
		scanf("%d",&ch);
		switch(ch){
			case 1:
				enqueue();
				break;
			case 2:
				dequeue();
				break;
			case 3:
				show();
				break;
			case 4:
				exit(0);
				break;
			default:
				printf("\n INCORRECT CHOICE \n");
		}
	}
}
void enqueue()
{
	int insert_item;
	if(rear==SIZE-1)
		printf("OVERFLOW \n");
	else{
		if(front==-1)
			front=0;
		printf("ELEMENT TO BE INSERTED IN THE QUEUE: \n");
		scanf("%d",&insert_item);
		rear=rear+1;
		inp_arr[rear]=insert_item;
	}
}
void dequeue()
{
	if(front==-1 || front>rear){
		printf("UNDERFLOW \n");
		return;
	}else{
		printf("ELEMENT DELETED FROM THE QUEUE: %d \n", inp_arr[front]);
		front=front+1;
	}
}
void show()
{
	if(front==-1)
		printf("EMPTY QUEUE \n");
	else{
		printf("QUEUE: \n");
	for(int i=front; i<=rear; i++)
		printf("%d ", inp_arr[i]);
		printf("\n");
	}
}
