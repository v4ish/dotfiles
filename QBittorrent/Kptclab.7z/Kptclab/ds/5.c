#include<stdio.h>
#include<stdlib.h>
struct node{
	int data;
	struct node *next;
}
*top=NULL;
void push(int);
void pop();
void display();
void main(){
	int choice,value;
	printf("\n STACK USING LINKED LIST \n");
	while(1){
		printf("\n****** MENU ******\n");
		printf(" 1: PUSH \n 2: POP \n 3: DISPLAY \n 4: EXIT \n");
		printf("ENTER YOUR CHOICE: ");
		scanf("%d",&choice);
		switch(choice){
			case 1:
				printf("ENTER THE VALUE TO BE INSERTED: ");
				scanf("%d",&value);
				push(value);
				break;
			case 2:
				pop();
				break;
			case 3:
				display();
				break;
			case 4:
				exit(0);
			default:
				printf("\n WRONG SELECTION !!! PLEASE TRY AGAIN \n");
			}
		}
	}
	void push(int value){
		struct node *newnode;
		newnode=(struct node*)malloc(sizeof(struct node));
		newnode->data=value;
		if(top==NULL)
			newnode->next=NULL;
		else
			newnode->next=top;
		top=newnode;
		printf("\n INSERTION IS SUCCESS !!! \n");
	}
	void pop(){
		if(top==NULL)
			printf("\n STACK IS EMPTY \n");
		else{
			struct node *temp=top;
			printf("\n DELETED ELEMENT: %d", temp->data);
			top=temp->next;
			free(temp);
		}
	}
	void display(){
		if(top==NULL)
			printf("\n STACK IS EMPTY \n");
		else{
			struct node *temp=top;
			while(temp->next != NULL){
				printf("%d --> ",temp->data);
				temp=temp->next;
			}
		printf("%d --> NULL",temp->data);
	}
}
