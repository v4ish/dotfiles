#include<stdio.h>
#include<stdlib.h>
struct node{
	int data;
	struct node *next;
};
struct node *front=NULL;
struct node *rear=NULL;
void enqueue(int value){
	struct node *newnode;
	newnode=(struct node*)malloc(sizeof(struct node));
	newnode->data=value;
	newnode->next=NULL;
	if((front==NULL)&&(rear==NULL))
		front=rear=newnode;
	else{
		rear->next=newnode;
		rear=newnode;
	}
	printf("\nNODE IS INSERTED \n\n");
}
int dequeue(){
	if(front==NULL){
		printf("\nUNDERFLOW\n");
		return -1;
	}
	else{
		struct node *temp=front;
		printf("POPPED ELEMENT IS : %d \n",temp->data);
		front=front->next;
		free(temp);
	}
}
void display(){
	struct node *temp;
	if((front==NULL)&&(rear==NULL))
		printf("\nQUEUE IS EMPTY\n\n");
	else{
		printf("\nTHE QUEUE IS \n");
		temp=front;
		while(temp){
			printf("%d-->",temp->data);
			temp=temp->next;
		}
		printf("NULL\n");
	}
}
void main(){
	int choice, value;
	printf("\nIMPLEMENTATION OF QUEUE USING LINKED LIST \n");
	while(choice != 4){
		printf("\n 1: ENQUEUE\n 2: DEQUEUE\n 3: DISPLAY\n 4: EXIT\n\n");
		printf("ENTER YOUR CHOICE: ");
		scanf("%d",&choice);
		switch(choice){
			case 1:
				printf("ENTER THE VALUE TO INSERT: ");
				scanf("%d",&value);
				enqueue(value);
				break;
			case 2:
				dequeue();
				break;
			case 3:
				display();
				break;
			case 4:
				exit(0);
			default:
				printf("\nINVALID CHOICE\n");
		}
	}
}
