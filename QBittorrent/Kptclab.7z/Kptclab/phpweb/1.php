<?php
function ispalindrome($n){
$copy=$n;
$rev=0;
for(; $n>0; $n=(int)($n/10))
{
$rev=$rev*10+$n%10;
}
if($copy==$rev)
{
echo $copy.' is palindrome number';
}
else
{
echo $copy.' is not palindrome number';
}
}
$n=121;
ispalindrome($n);
?>