<?php
$size=array("car\t","bike\t","cycle\t");
echo"vehicle\n",$size[0],$size[1],$size[2];
?>